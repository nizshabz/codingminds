import {Component} from "@angular/core";
@Component({
  template: '<h1>Component 1</h1>'
})
export class Component1Component{

}