import {Component} from "@angular/core";
@Component({
  templateUrl: '/sample/ng/'
})
export class DjangoComponent{
  ngVariable = "This is angular2 component property with interpolation";

}
